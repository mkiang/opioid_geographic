#' Mapping original FIPS codes to temporally stable FIPS codes from IHME
#'
#' Counties change over time, which can make comparing across two different
#' time periods difficult. Researchers often use temporally-stable FIPS
#' designations to simplify comparing counties across long time periods. This
#' dataframe comes from the appendix of Dwyer-Lindgren L, et al. US
#' County-Level Trends in Mortality Rates for Major Causes of Death, 1980-2014.
#' JAMA. 2016;316(22):2385–2401. doi:10.1001/jama.2016.13645
#'
#' @docType data
#'
#' @format A data frame with 77 rows and 4 columns
#' \describe{
#'   \item{state}{character, name of state}
#'   \item{group}{character, grouping of FIPS characters to be collapsed}
#'   \item{orig_fips}{character, FIPS code from the US Census}
#'   \item{ihme_fips}{character, temporally stable FIPS code from IHME}
#' }
#' @source \url{http://jamanetwork.com/journals/jama/fullarticle/2592499}
#' @keywords datasets
"ihme_fips"
