.onLoad <- function(libname, pkgname){
    options(imgur_user_rate_warning = 20)
    options(imgur_client_rate_warning = 100)
}