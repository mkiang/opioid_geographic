## Why an update?
* fix issues identified by CRAN
* compatibility with new ggplot2

## FIXED the DESCRIPTION error noted by Kurt

## ALSO NOTE that these words are *not* mis-spelled.

  Cartogram (3:19)
  Choropleth (3:62)
  Heatmaps (3:29)
  choropleth (9:45)
  statebins (9:14, 11:47)

## Test environments
* local OS X install (devel and release)
* ubuntu 12.04 (on travis-ci), R
* win-builder (devel and release)

## R CMD check results
There were no ERRORs or WARNINGs. 

One NOTE:

Maintainer: ‘Bob Rudis <bob@rudis.net>

License components with restrictions and base license permitting such:
  MIT + file LICENSE
File 'LICENSE':
  YEAR: 2015
  COPYRIGHT HOLDER: Bob Rudis
