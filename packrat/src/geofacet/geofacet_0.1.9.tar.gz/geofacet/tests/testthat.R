library(testthat)
library(geofacet)

test_check("geofacet")
