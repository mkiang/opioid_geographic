Version 0.1
----------------------------------------------------------------------

- Add new grids (0.1.9)
- Integration with geogrid package with new function `grid_auto()` (0.1.9)
- Fix issue with plotting in R Markdown and ggsave (0.1.9)
- Search for data in layers as well as global data for facet setup (0.1.9)
- Fix bug in filtering gtable with large grids (0.1.8)
- Several new grids (0.1.8)
- Several new grids (0.1.7)
- Add plot method in addition to print method for facet_geo objects (0.1.7)
- 17 new grids
- Fix vignette redirect
